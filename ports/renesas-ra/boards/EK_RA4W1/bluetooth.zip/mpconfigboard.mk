CMSIS_MCU = RA4W1
MCU_SERIES = m4
LD_FILES = boards/EK_RA4W1/ra4w1_ek.ld

# MicroPython settings
MICROPY_VFS_FAT = 1

# Native BLE support using FSP BLE stack
MICROPY_HW_ENABLE_BLE = 1

CFLAGS+=-DDEFAULT_DBG_CH=0

# Use a board-specific frozen manifest so we can provide EK_RA4W1-specific
# Python compatibility shims (e.g. `bluetooth` wrapper over `renesas_ble`).
FROZEN_MANIFEST = $(BOARD_DIR)/manifest.py
